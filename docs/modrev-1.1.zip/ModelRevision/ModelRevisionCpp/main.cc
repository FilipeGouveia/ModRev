#include "main.h"
#include "Configuration.h"
#include <iostream>
#include <fstream>
#include <string>
#include "ASPHelper.h"
#include "Network.h"
#include "Util.h"
#include <bitset>
#include <algorithm>
#include <math.h>

//same as used in InconsistencySolution and InconsistentNode
enum inconsistencies { CONSISTENT = 0, SINGLE_INC_GEN, SINGLE_INC_PART, DOUBLE_INC };

Network * network = new Network();

int main(int argc, char ** argv) {

    Configuration::parseConfig();

    std::string input_file_network, output_file;

    //printAllFunctions(6);

    if(argc < 2)
    {
        std::cout << "Invalid number of arguments: " << argc << std::endl;
        return -1;
    }

    process_arguments(argc, argv, input_file_network, output_file);

    ASPHelper::parseNetwork(input_file_network, network);

    network->input_file_network_ = input_file_network;
    //main function that revises the model
    modelRevision(input_file_network);

/*     std::vector<Edge*> vt;
    Node* n = network->getNode("c3");
    std::map<std::string,int> map = n->getFunction()->getRegulatorsMap();
    for(auto it = map.begin(), end = map.end(); it!= end; it++)
    {
            Edge* e = network->getEdge(it->first, "c3");
            vt.push_back(e);
    }
    for(int i = 1; i < 4; i++)
    {
        auto aux = getEdgesCombinations(vt,i);
        std::cout << "#### edges with " << i << " combinations\n";
        for(auto it1 = aux.begin(), end1 = aux.end(); it1!=end1; it1++)
        {
            std::cout << "\t---\n";
            for(auto it2 = (*it1).begin(), end2 = (*it1).end(); it2!=end2; it2++)
            {
                std::cout << "\t from " << (*it2)->start_->id_ << "\n";
            }
        }
    } */
    
}


// Function that initializes the program.
// Can process optional arguments or configurations
void process_arguments(const int argc, char const * const * argv, std::string & input_file_network, std::string & output_file) {

    input_file_network = argv[1];

    if(argc > 2)
        output_file = argv[2];

    return;
}



//Model revision procedure
// 1) tries to repair functions
// 2) tries to flip the sign of the edges
// 3) tries to add or remove edges
void modelRevision(std::string input_file_network) {

    int optimization = -2;

    std::vector<InconsistencySolution*> fInconsistencies = checkConsistencyFunc(input_file_network, optimization);
    if(optimization == 0)
    {
        return;
    }
    if(Configuration::isActive("debug"))
        std::cout << "found " << fInconsistencies.size() << " solutions with " << fInconsistencies.front()->iNodes_.size() << " inconsistent nodes" << std::endl;

    //At this point we have an inconsistent network with node candidates to be repaired

    //for each possible inconsistency solution/labelling, try to make the model consistent
    InconsistencySolution * bestSolution = nullptr;
    for(auto it = fInconsistencies.begin(), end = fInconsistencies.end(); it != end; it++)
    {
        repairInconsistencies((*it));

        //TODO
        if(!(*it)->hasImpossibility)
        {
            if(bestSolution == nullptr || (*it)->getNTopologyChanges() < bestSolution->getNTopologyChanges())
            {
                bestSolution = (*it);
                if(Configuration::isActive("debug"))
                    std::cout << "DEBUG: found solution with " << bestSolution->getNTopologyChanges() << " topology changes.\n";
                if(bestSolution->getNTopologyChanges() == 0 && !Configuration::isActive("allOpt"))
                    break;
            }
        }
        else
        {
            if(Configuration::isActive("debug"))
                std::cout << "Reached an impossibility\n";
        }
    }

    if(bestSolution == nullptr)
    {
        std::cout << "### It was not possible to repair the model." << std::endl;
        return;
    }
    
    //TODO
    if(Configuration::isActive("allOpt"))
    {
        //TODO: remove duplicates
        for(auto it = fInconsistencies.begin(), end = fInconsistencies.end(); it != end; it++)
        {
            if(Configuration::isActive("debug"))
                std::cout << "DEBUG: checking for printing solution with " << (*it)->getNTopologyChanges() << " topology changes\n";
            if(!(*it)->hasImpossibility && (*it)->getNTopologyChanges() == bestSolution->getNTopologyChanges())
            {
                (*it)->printSolution();
            }
        }

    }
    else
    {
        bestSolution->printSolution();
    }

}


//function reponsible to check the consistency of a model and return a set of possible function inconsistencies
std::vector<InconsistencySolution*> checkConsistencyFunc(std::string input_file_network, int & optimization) {

    std::vector<std::vector<std::string>> result_raw;
    std::vector<InconsistencySolution*> result;
    
    //consistency check
    if(Configuration::isActive("check_ASP"))
    {
        // invoke the consistency check program in ASP
        optimization = ASPHelper::checkConsistency(input_file_network, result_raw);
    }
    else
    {
        //TODO Add other implementations
        //convert ASP to sat or other representation
        //test consistency
    }

    //TODO Consider repair edges
    if(optimization < 0)
    {
        std::cout << "It is not possible to repair this network for now." << std::endl;
    }

    if(optimization == 0)
    {
        std::cout << "This network is consistent!" << std::endl;
    }

    if(optimization > 0 && Configuration::isActive("check_ASP"))
    {
        //parse the raw results to an internal representation.
        //this should be done at ASP level in the check consistency function
        //TODO
        result = ASPHelper::parseFunctionRepairResults(result_raw);
    }

    return result;
}



//This function receives an inconsistent model with a set of nodes to be repaired and try to repair the target nodes making the model consistent
//returns the set of repair operations to be applied
void repairInconsistencies(InconsistencySolution* inconsistency)
{

    //repair each inconsistent node
    for(auto it = inconsistency->iNodes_.begin(), end = inconsistency->iNodes_.end(); it != end; it++)
    {

        repairNodeConsistency(inconsistency, it->second);
        if(inconsistency->hasImpossibility)
        {
            //one of the nodes was not possible to repair
            if(Configuration::isActive("debug"))
                printf("#FOUND a node with impossibility - %s\n", it->second->id_.c_str());
            return;
        }
        
    }

}

//This function repair a given node and determines all possible solutions
void repairNodeConsistency(InconsistencySolution* inconsistency, InconsistentNode* iNode)
{
    //double inconsistent case
    if(iNode->repairType > 2)
    {
        if(Configuration::isActive("debug"))
            printf("#FOUND a node with double inconsistency - %s\n", iNode->id_.c_str());
        //inconsistency->hasImpossibility = true;
        std::vector<Edge *> emptyList;
        bool res = searchNonComparableFunctions(inconsistency, iNode, emptyList, emptyList, emptyList);
        if(!res)
        {
            repairNodeConsistencyWithTopologyChanges(inconsistency, iNode);
        }
        //throw std::invalid_argument( "end of double inconsistency" );
        //return;
    }
    else
    {
        if(Configuration::isActive("debug"))
            printf("#FOUND a node with single inconsistency - %s\n", iNode->id_.c_str());
        std::vector<std::vector<Function*>> candidates;

        if(Configuration::isActive("function_ASP"))
        {

            //each function must have a list of replacement candidates and each must be tested until it works
            Function* originalF = network->getNode(iNode->id_)->getFunction();
            if(originalF == nullptr)
            {
                std::cout << "WARN: Inconsistent node " << iNode->id_ << " without regulatory function." << std::endl;
                inconsistency->hasImpossibility = true;
                return;
            }

            //if the function only has 1 regulator then it is not possible to change the function
            //better try to flip the sign of the edge
            //check top function for the necessity of flipping an edge <- yhis only works for single profile
            
            //if(originalF->getNumberOfRegulators() < 2 || !checkPointFunction(inconsistency, originalF, iNode->generalization_))
            if(originalF->getNumberOfRegulators() < 2)
            {
                repairNodeConsistencyWithTopologyChanges(inconsistency, iNode);
                return;
            }

            // get the possible candidates to replace the inconsistent function
            bool functionRepaired = false;
            int repairedFunctionLevel = -1;
            std::vector<Function*> tCandidates = ASPHelper::getFunctionReplace(originalF,iNode->generalization_, network->input_file_network_);
            while(!tCandidates.empty())
            {
                Function* candidate = tCandidates.front();
                tCandidates.erase (tCandidates.begin());
                
                if(functionRepaired && candidate->level_ > repairedFunctionLevel)
                {
                    //function is from a higher level than expected
                    continue;
                }

                if(isFuncConsistentWithLabel(inconsistency, candidate))
                {

                    RepairSet * repairSet = new RepairSet();
                    repairSet->addRepairedFunction(candidate);
                    inconsistency->addRepairSet(iNode->id_, repairSet);
                    functionRepaired = true;
                    repairedFunctionLevel = candidate->level_;
                    if(!Configuration::isActive("showAllFunctions"))
                    {
                        break;
                    }
                }

                std::vector<Function*> tauxCandidates = ASPHelper::getFunctionReplace(candidate,iNode->generalization_, network->input_file_network_);
                if(!tauxCandidates.empty())
                    tCandidates.insert(tCandidates.end(),tauxCandidates.begin(),tauxCandidates.end());
                
            }
            if(!functionRepaired)
            {
                //not possible to repair without topology changes
                //For 1 profile is not suposed to reach this point
                repairNodeConsistencyWithTopologyChanges(inconsistency, iNode);
            }
            
        }
        else
        {
        //TODO support other solvers
        } 
    }
    return;
}

bool isFuncConsistentWithLabel(InconsistencySolution* labeling, Function* f)
{
    //verify for each profile
    for(auto it = labeling->vlabel_.begin(), end = labeling->vlabel_.end(); it != end; it++)
    {
        if(!isFuncConsistentWithLabel(labeling, f, it->first))
            return false;
    }
    return true;
}

bool isFuncConsistentWithLabel(InconsistencySolution* labeling, Function* f, std::string profile)
{
    for(int i = 1; i <= f->nClauses_; i++)
    {
        bool isClauseSatisfiable = true;
        std::vector<std::string> clause = f->clauses_[i];
        for(auto it = clause.begin(), end = clause.end(); it!=end; it++)
        {
            Edge* e = network->getEdge((*it), f->node_);
            if(e != nullptr)
            {
                //positive interaction
                if(e->getSign() > 0)
                {
                    if(labeling->vlabel_[profile][(*it)] == 0)
                    {
                        isClauseSatisfiable = false;
                        break;
                    }
                }
                //negative interaction
                else
                {
                    if(labeling->vlabel_[profile][(*it)] > 0)
                    {
                        isClauseSatisfiable = false;
                        break;
                    }
                }
            }
            else{
                std::cout << "WARN: Missing edge from " << (*it) << " to " << f->node_ << std::endl;
                return false;
            }
        }
        if(isClauseSatisfiable)
            return labeling->vlabel_[profile][f->node_] == 1;

    }
    return labeling->vlabel_[profile][f->node_] == 0;
}

bool checkPointFunction(InconsistencySolution* labeling, Function* f, bool generalize)
{
    //for each profile
    for(auto it = labeling->vlabel_.begin(), end = labeling->vlabel_.end(); it != end; it++)
    {
        if(!checkPointFunction(labeling, f, it->first, generalize))
            return false;
    }
    return true;
}
//checks thhe top or bottom function for consistency.
// Allows to check if it is possible to repair a function without changing the topology
bool checkPointFunction(InconsistencySolution* labeling, Function* f, std::string profile, bool generalize){
    std::map<std::string,int> map = f->getRegulatorsMap();
    if(generalize)
    {
        // disjunction of all regulators
        for(auto it = map.begin(), end = map.end(); it!= end; it++)
        {
            Edge* e = network->getEdge(it->first, f->node_);
            if(e != nullptr)
            {
                //positive interaction
                if(e->getSign() > 0 && labeling->vlabel_[profile][it->first] > 0)
                {
                    return true;
                }
                //negative interaction
                if(e->getSign() == 0 && labeling->vlabel_[profile][it->first] == 0)
                {
                    return true;
                }
            }
            else{
                std::cout << "WARN: Missing edge from " << it->first << " to " << f->node_ << std::endl;
                return false;
            }
        }
        return false;
    }
    else{
        // conjunction of all regulators
        // as this is a particularization, it is needed more zeros and the function evaluation should be 0
        for(auto it = map.begin(), end = map.end(); it!= end; it++)
        {
            Edge* e = network->getEdge(it->first, f->node_);
            if(e != nullptr)
            {
                //positive interaction
                if(e->getSign() > 0 && labeling->vlabel_[profile][it->first] == 0)
                {
                    return true;
                }
                //negative interaction
                if(e->getSign() == 0 && labeling->vlabel_[profile][it->first] > 0)
                {
                    return true;
                }
            }
            else{
                std::cout << "WARN: Missing edge from " << it->first << " to " << f->node_ << std::endl;
                return false;
            }
        }
        return false;
    }
    return true;

}

//this only works for flipping edges
//TODO consider this function for no flipping edges
void repairNodeConsistencyWithTopologyChanges(InconsistencySolution* solution, InconsistentNode* iNode)
{

    std::vector<Edge*> emptyList;
    bool solFound = repairNodeConsistencyFlippingEdges(solution, iNode, emptyList, emptyList);

    //try to add or remove edges
    if(!solFound)
    {
        if(Configuration::isActive("debug"))
            std::cout << "DEBUG: Not possible to only flip edges to repair function " << iNode->id_ << std::endl;

        repairNodeConsistencyByRegulators(solution, iNode);
    }

}


bool repairNodeConsistencyFlippingEdges(InconsistencySolution* solution, InconsistentNode* iNode, std::vector<Edge*> addedEdges, std::vector<Edge*> removedEdges)
{
    Function * f = network->getNode(iNode->id_)->regFunction_;
    std::map<std::string,int> map = f->getRegulatorsMap();
    std::vector<Edge*> listEdges;
    for(auto it = map.begin(), end = map.end(); it!= end; it++)
    {
        Edge* e = network->getEdge(it->first, f->node_);
        if(e!=nullptr && !e->isFixed())
        {
            listEdges.push_back(e);
        }
    }

    if(Configuration::isActive("debug"))
        std::cout << "DEBUG: searching solution flipping edges for " << iNode->id_ << "\n";

    bool solFound = false;
    for(int nEdges = 1; nEdges <= (int)listEdges.size(); nEdges++)
    {
        if(Configuration::isActive("debug"))
            std::cout << "DEBUG: testing with " << nEdges << " edge flips\n";
        std::vector<std::vector<Edge*>> eCandidates = getEdgesCombinations(listEdges, nEdges);

        if(iNode->repairType > 2)
        {
            //for each set of flipping edges
            for(auto it = eCandidates.begin(), end = eCandidates.end(); it!= end; it++)
            {
                //flip all edges
                for(auto itEdge = (*it).begin(), endEdge = (*it).end(); itEdge != endEdge; itEdge++)
                {
                    Edge* e = (*itEdge);
                    e->flipSign();
                    if(Configuration::isActive("debug"))
                        std::cout << "DEBUG: flip edge from " << e->start_->id_ << "\n";
                }
                bool isSol = false;
                int nInc = nFuncInconsistWithLabel(solution, f);
                if(nInc > CONSISTENT)
                {
                    if(nInc == DOUBLE_INC)
                    {
                        isSol = searchNonComparableFunctions(solution, iNode, (*it), addedEdges, removedEdges);
                    }
                    else
                    {
                        iNode->generalization_ = nInc == SINGLE_INC_GEN;
                        isSol = searchComparableFunctions(solution, iNode, (*it), addedEdges, removedEdges);
                    }
                }
                else
                {
                    isSol = true;
                    RepairSet * repairSet = new RepairSet();
                    for(auto itEdge = (*it).begin(), endEdge = (*it).end(); itEdge != endEdge; itEdge++)
                    {
                        Edge* e = (*itEdge);
                        repairSet->addFlippedEdge(e);
                    }
                    //add and remove edges in solution repair set
                    for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                    {
                        repairSet->removeEdge((*itRem));
                    }
                    for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                    {
                        repairSet->removeEdge((*itAdd));
                    }

                    solution->addRepairSet(iNode->id_, repairSet);

                }
                //put network back to normal
                for(auto itEdge = (*it).begin(), endEdge = (*it).end(); itEdge != endEdge; itEdge++)
                {
                    Edge* e = (*itEdge);
                    e->flipSign();
                    if(Configuration::isActive("debug"))
                        std::cout << "DEBUG: return flip edge from " << e->start_->id_ << "\n";
                }
                if(isSol)
                {
                    solFound = true;
                    if(!Configuration::isActive("allOpt"))
                    {
                        if(Configuration::isActive("debug"))
                            std::cout << "DEBUG: no more solutions - allOpt\n";
                        return true;
                    }
                }
            }
        }
        else
        {
            //TODO REFACT THE CODE
            std::vector<Function*> fCandidates;
            fCandidates.push_back(f);
            int bestFunctionLevel = -1;
            //This is used to check if we can repair the node without changing the function.
            //If so, do not add a new function to the solution, only include flipping the edge.

            while(!fCandidates.empty())
            {
                Function* candidate = fCandidates.front();
                fCandidates.erase (fCandidates.begin());

                if(bestFunctionLevel >= 0 && candidate->level_ > bestFunctionLevel)
                {
                    //function is from a higher level than expected
                    continue;
                }

                //for each set of flipping edges
                for(auto it = eCandidates.begin(), end = eCandidates.end(); it!= end; it++)
                {
                    //flip all edges
                    for(auto itEdge = (*it).begin(), endEdge = (*it).end(); itEdge != endEdge; itEdge++)
                    {
                        Edge* e = (*itEdge);
                        e->flipSign();
                        if(Configuration::isActive("debug"))
                            std::cout << "DEBUG: flip edge from " << e->start_->id_ << "\n";
                    }
                    bool isSol = false;
                    if(Configuration::isActive("debug"))
                            std::cout << "DEBUG: testing function " << candidate->printFunction() << "\n";
                    if(isFuncConsistentWithLabel(solution, candidate))
                    {
                        if(Configuration::isActive("debug"))
                            std::cout << "DEBUG: found solution with " << nEdges << " edges flipped\n";
                        isSol = true;
                        solFound = true;
                    }
                    //put network back to normal
                    RepairSet * repairSet = new RepairSet();
                    for(auto itEdge = (*it).begin(), endEdge = (*it).end(); itEdge != endEdge; itEdge++)
                    {
                        Edge* e = (*itEdge);
                        e->flipSign();
                        if(Configuration::isActive("debug"))
                            std::cout << "DEBUG: return flip edge from " << e->start_->id_ << "\n";
                        if(isSol)
                        {
                            repairSet->addFlippedEdge(e);
                        }
                    }
                    if(isSol)
                    {
                        //Only add a function repair operations if the candidate is not the original
                        if(candidate->level_ > 0)
                        {
                            if(Configuration::isActive("debug"))
                                std::cout << "DEBUG: solution without original function\n";
                            repairSet->addRepairedFunction(candidate);
                        }

                        //add and remove edges in solution repair set
                        for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                        {
                            repairSet->removeEdge((*itRem));
                        }
                        for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                        {
                            repairSet->removeEdge((*itAdd));
                        }

                        solution->addRepairSet(iNode->id_, repairSet);
                        bestFunctionLevel = candidate->level_;
                        if(!Configuration::isActive("allOpt"))
                        {
                            if(Configuration::isActive("debug"))
                                std::cout << "DEBUG: no more solutions - allOpt\n";
                            return true;
                        }
                    }
                }
                if(bestFunctionLevel >= 0 && !Configuration::isActive("showAllFunctions"))
                {
                    if(Configuration::isActive("debug"))
                        std::cout << "DEBUG: no more function solutions\n";
                    return true;           
                }

            
                if(candidate->getNumberOfRegulators() < 2)
                {
                    if(Configuration::isActive("debug"))
                        std::cout << "DEBUG: function with 1 regulator\n";
                    //there is no possible condidates for 1 regulator function
                    break;
                }
                //renew candidates if solution level not found yet
                if(bestFunctionLevel < 0 || candidate->level_ < bestFunctionLevel)
                {
                    if(Configuration::isActive("debug"))
                        std::cout << "DEBUG: updating solutions\n";
                    std::vector<Function*> fauxCandidates = ASPHelper::getFunctionReplace(candidate, iNode->generalization_, network->input_file_network_);
                    if(!fauxCandidates.empty())
                        fCandidates.insert(fCandidates.end(),fauxCandidates.begin(),fauxCandidates.end());
                }

            }

            //If the end of this method is reached means that no solution was found with nEdges
            if(solFound)
            {
                if(Configuration::isActive("debug"))
                    std::cout << "DEBUG: ready to end with " << nEdges << " edges flipped\n";
                break;
            }
            if(Configuration::isActive("debug"))
                std::cout << "DEBUG: reached the end of " << nEdges << " without solution\n";

        }
    }
    
    return solFound;
}


std::vector<std::vector<Edge *>> getEdgesCombinations(std::vector<Edge *> edges, int n)
{
    if(n == 0)
    {
        std::vector<std::vector<Edge *>> result;
        return result;
    }
    return getEdgesCombinations(edges, n, 0);
}

std::vector<std::vector<Edge *>> getEdgesCombinations(std::vector<Edge *> edges, int n, int indexStart)
{
    std::vector<std::vector<Edge *>> result;

    for(int i = indexStart; i <= (int)edges.size() - n; i++)
    {
        if(n > 1)
        {
            std::vector<std::vector<Edge *>> aux = getEdgesCombinations(edges, n-1, i+1);
            for(auto it = aux.begin(), end=aux.end(); it!=end; it++)
            {
                (*it).push_back(edges[i]);
                result.push_back((*it));
            }

        }
        else
        {
            std::vector<Edge*> finalAux;
            finalAux.push_back(edges[i]);
            result.push_back(finalAux);
        }
    }

    return result;
}


//TODO make this functions only one
void repairNodeConsistencyByRegulators(InconsistencySolution* solution, InconsistentNode* iNode)
{
    if(Configuration::isActive("debug"))
        std::cout << "DEBUG: searching solution adding or removing edges for " << iNode->id_ << "\n";
    Node * originalN = network->getNode(iNode->id_);
    Function * originalF = originalN->regFunction_;

    std::map<std::string,int> originalMap = originalF->getRegulatorsMap();
    std::vector<Edge*> listEdgesRemove;
    std::vector<Edge*> listEdgesAdd;

    for(auto it = originalMap.begin(), end = originalMap.end(); it!= end; it++)
    {
        Edge* e = network->getEdge(it->first, originalF->node_);
        if(e!=nullptr && !e->isFixed())
        {
            listEdgesRemove.push_back(e);
        }
    }

    int maxNRemove = (int)listEdgesRemove.size();
    int maxNAdd = (int)network->nodes_.size() - maxNRemove;

    for(auto it = network->nodes_.begin(), end = network->nodes_.end(); it!= end; it++)
    {
        bool isOriginalRegulator = false;
        for(auto it2 = originalMap.begin(), end2 = originalMap.end(); it2!=end2; it2++)
        {
            if(it->first.compare(it2->first) == 0)
            {
                isOriginalRegulator = true;
                break;
            }
        }
        if(!isOriginalRegulator)
        {
            Edge* newEdge = new Edge(it->second, originalN, 1);
            listEdgesAdd.push_back(newEdge);
        }
    }
    bool solFound = false;

    //iteration of number of add/remove operations
    for(int nOperations = 1; nOperations <= maxNRemove + maxNAdd; nOperations++)
    {

        for(int nAdd = 0; nAdd <= nOperations; nAdd++)
        {
            if(nAdd > maxNAdd)
            {
                break;
            }
            int nRemove = nOperations - nAdd;
            if(nRemove > maxNRemove)
            {
                continue;
            }

            if(nAdd == 0 && nRemove == 0)
            {
                continue;
            }
            if(Configuration::isActive("debug"))
                std::cout << "DEBUG: Testing " << nAdd << " adds and " << nRemove << " removes\n";

            std::vector<std::vector<Edge *>> listAddCombination = getEdgesCombinations(listEdgesAdd, nAdd);
            std::vector<std::vector<Edge *>> listRemoveCombination = getEdgesCombinations(listEdgesRemove, nRemove);
            std::vector<Edge *> emptyList;

            //only remove
            if(nAdd == 0)
            {

                for(auto itRemove = listRemoveCombination.begin(), endRemove = listRemoveCombination.end(); itRemove != endRemove; itRemove++)
                {
                    bool isSol = false;

                    //remove edges
                    for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                    {
                        network->removeEdge(*itRem);
                    }

                    //new function
                    Function * newF = new Function(originalN->id_, 0);
                    int clauseId = 1;
                    for(auto itReg = originalMap.begin(), endReg = originalMap.end(); itReg != endReg; itReg++)
                    {
                        bool removed = false;
                        for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                        {
                            if(itReg->first.compare((*itRem)->start_->id_) == 0)
                            {
                                removed = true;
                                break;
                            }
                        }
                        if(!removed)
                        {
                            newF->addElementClause(clauseId, itReg->first);
                            clauseId++;
                        }
                    }
                    originalN->addFunction(newF);

                    //test only functions
                    std::vector<Function*> fCandidates;

                    //test special case where all the edges are removed - node turned into input
                    if(clauseId == 1)
                    {
                        isSol = true;
                        RepairSet * repairSet = new RepairSet();
                        //remove edges in solution repair set
                        for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                        {
                            repairSet->removeEdge((*itRem));
                        }
                        repairSet->addRepairedFunction(newF);
                        solution->addRepairSet(iNode->id_, repairSet);
                    }
                    else
                    {
                        fCandidates.push_back(newF);
                    }

                    if(iNode->repairType > 2)
                    {
                        int nInc = nFuncInconsistWithLabel(solution, newF);
                        if(nInc > CONSISTENT)
                        {
                            if(nInc == DOUBLE_INC)
                            {
                                isSol = searchNonComparableFunctions(solution, iNode, emptyList, emptyList, (*itRemove));
                            }
                            else
                            {
                                iNode->generalization_ = nInc == SINGLE_INC_GEN;
                                isSol = searchComparableFunctions(solution, iNode, emptyList, emptyList, (*itRemove));
                            }
                        }
                        else
                        {
                            isSol = true;
                            RepairSet * repairSet = new RepairSet();
                            //remove edges in solution repair set
                            for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                            {
                                repairSet->removeEdge((*itRem));
                            }
                            repairSet->addRepairedFunction(newF);
                            solution->addRepairSet(iNode->id_, repairSet);
                        }
                    }
                    else
                    {
                        int bestFunctionLevel = -1;
                        while(!fCandidates.empty())
                        {
                            Function* candidate = fCandidates.front();
                            fCandidates.erase (fCandidates.begin());

                            if(bestFunctionLevel >= 0 && candidate->level_ > bestFunctionLevel)
                            {
                                //function is from a higher level than expected
                                continue;
                            }

                            if(isFuncConsistentWithLabel(solution, candidate))
                            {
                                isSol = true;
                            }

                            if(isSol)
                            {
                                RepairSet * repairSet = new RepairSet();

                                repairSet->addRepairedFunction(candidate);

                                //remove edges in solution repair set
                                for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                                {
                                    repairSet->removeEdge((*itRem));
                                }

                                solution->addRepairSet(iNode->id_, repairSet);
                                bestFunctionLevel = candidate->level_;
                                if(!Configuration::isActive("allOpt"))
                                {
                                    if(Configuration::isActive("debug"))
                                        std::cout << "DEBUG: no more solutions - allOpt\n";
                                    break;;
                                }
                                
                            }
                            if(bestFunctionLevel >= 0 && !Configuration::isActive("showAllFunctions"))
                            {
                                if(Configuration::isActive("debug"))
                                    std::cout << "DEBUG: no more function solutions\n";
                                break;           
                            }

                            if(candidate->getNumberOfRegulators() < 2)
                            {
                                if(Configuration::isActive("debug"))
                                    std::cout << "DEBUG: function with 1 regulator\n";
                                //there is no possible condidates for 1 regulator function
                                break;
                            }
                            //renew candidates if solution level not found yet
                            if(bestFunctionLevel < 0 || candidate->level_ < bestFunctionLevel)
                            {
                                if(Configuration::isActive("debug"))
                                    std::cout << "DEBUG: updating solutions\n";
                                std::vector<Function*> fauxCandidates = ASPHelper::getFunctionReplace(candidate, iNode->generalization_, network->input_file_network_);
                                if(!fauxCandidates.empty())
                                    fCandidates.insert(fCandidates.end(),fauxCandidates.begin(),fauxCandidates.end());
                            }

                        }
                    }

                    //test with edge flips
                    if(!isSol)
                        isSol = repairNodeConsistencyFlippingEdges(solution, iNode, emptyList, (*itRemove));


                    //add removed edges for the original network
                    for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                    {
                        network->addEdge((*itRem));
                    }

                    //put back the original function
                    originalN->addFunction(originalF);

                    if(isSol)
                    {
                        solFound = true;
                        if(!Configuration::isActive("allOpt"))
                        {
                            if(Configuration::isActive("debug"))
                                std::cout << "DEBUG: no more solutions - allOpt\n";
                            return;
                        }
                    }

                }
            }
            else
            {
                //only add
                if(nRemove == 0)
                {

                    for(auto itAdd = listAddCombination.begin(), endAdd = listAddCombination.end(); itAdd != endAdd; itAdd++)
                    {
                        bool isSol = false;

                        //add edges
                        for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                        {
                            network->addEdge(*itA);
                        }

                        //new function
                        Function * newF = new Function(originalN->id_, 0);
                        int clauseId = 1;
                        for(auto itReg = originalMap.begin(), endReg = originalMap.end(); itReg != endReg; itReg++)
                        {
                            newF->addElementClause(clauseId, itReg->first);
                            clauseId++;
                        }
                        for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                        {
                            newF->addElementClause(clauseId, (*itA)->start_->id_);
                            clauseId++;
                        }

                        originalN->addFunction(newF);

                        if(iNode->repairType > 2)
                        {
                            int nInc = nFuncInconsistWithLabel(solution, newF);
                            if(nInc > CONSISTENT)
                            {
                                if(nInc == DOUBLE_INC)
                                {
                                    isSol = searchNonComparableFunctions(solution, iNode, emptyList, (*itAdd), emptyList);
                                }
                                else
                                {
                                    iNode->generalization_ = nInc == SINGLE_INC_GEN;
                                    isSol = searchComparableFunctions(solution, iNode, emptyList, (*itAdd), emptyList);
                                }
                            }
                            else
                            {
                                isSol = true;
                                RepairSet * repairSet = new RepairSet();
                                //add edges in solution repair set
                                for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                                {
                                    repairSet->addEdge((*itA));
                                }
                                repairSet->addRepairedFunction(newF);
                                solution->addRepairSet(iNode->id_, repairSet);
                            }
                        }
                        else
                        {
                            //test only functions
                            std::vector<Function*> fCandidates;
                            fCandidates.push_back(newF);
                            int bestFunctionLevel = -1;
                            while(!fCandidates.empty())
                            {
                                Function* candidate = fCandidates.front();
                                fCandidates.erase (fCandidates.begin());

                                if(bestFunctionLevel >= 0 && candidate->level_ > bestFunctionLevel)
                                {
                                    //function is from a higher level than expected
                                    continue;
                                }

                                if(isFuncConsistentWithLabel(solution, candidate))
                                {
                                    isSol = true;
                                }


                                if(isSol)
                                {
                                    RepairSet * repairSet = new RepairSet();

                                    repairSet->addRepairedFunction(candidate);

                                    //add edges in solution repair set
                                    for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                                    {
                                        repairSet->addEdge((*itA));
                                    }

                                    solution->addRepairSet(iNode->id_, repairSet);
                                    bestFunctionLevel = candidate->level_;
                                    if(!Configuration::isActive("allOpt"))
                                    {
                                        if(Configuration::isActive("debug"))
                                            std::cout << "DEBUG: no more solutions - allOpt\n";
                                        break;;
                                    }
                                    
                                }
                                if(bestFunctionLevel >= 0 && !Configuration::isActive("showAllFunctions"))
                                {
                                    if(Configuration::isActive("debug"))
                                        std::cout << "DEBUG: no more function solutions\n";
                                    break;           
                                }

                                if(candidate->getNumberOfRegulators() < 2)
                                {
                                    if(Configuration::isActive("debug"))
                                        std::cout << "DEBUG: function with 1 regulator\n";
                                    //there is no possible condidates for 1 regulator function
                                    break;
                                }
                                //renew candidates if solution level not found yet
                                if(bestFunctionLevel < 0 || candidate->level_ < bestFunctionLevel)
                                {
                                    if(Configuration::isActive("debug"))
                                        std::cout << "DEBUG: updating solutions\n";
                                    std::vector<Function*> fauxCandidates = ASPHelper::getFunctionReplace(candidate, iNode->generalization_, network->input_file_network_);
                                    if(!fauxCandidates.empty())
                                        fCandidates.insert(fCandidates.end(),fauxCandidates.begin(),fauxCandidates.end());
                                }

                            }
                        }

                        //test with edge flips
                        if(!isSol)
                            isSol = repairNodeConsistencyFlippingEdges(solution, iNode, (*itAdd), emptyList);

                        //remove added edges for the original network
                        for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                        {
                            network->removeEdge((*itA));
                        }

                        //put back the original function
                        originalN->addFunction(originalF);

                        if(isSol)
                        {
                            solFound = true;
                            if(!Configuration::isActive("allOpt"))
                            {
                                if(Configuration::isActive("debug"))
                                    std::cout << "DEBUG: no more solutions - allOpt\n";
                                return;
                            }
                        }

                    }

                }
                //both add and remove operations
                else
                {
                    for(auto itAdd = listAddCombination.begin(), endAdd = listAddCombination.end(); itAdd != endAdd; itAdd++)
                    {
                        for(auto itRemove = listRemoveCombination.begin(), endRemove = listRemoveCombination.end(); itRemove != endRemove; itRemove++)
                        {

                            bool isSol = false;

                            //remove and add edges
                            for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                            {
                                network->removeEdge(*itRem);
                            }
                            for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                            {
                                network->addEdge(*itA);
                            }

                            //new function
                            Function * newF = new Function(originalN->id_, 0);
                            int clauseId = 1;
                            for(auto itReg = originalMap.begin(), endReg = originalMap.end(); itReg != endReg; itReg++)
                            {
                                bool removed = false;
                                for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                                {
                                    if(itReg->first.compare((*itRem)->start_->id_) == 0)
                                    {
                                        removed = true;
                                        break;
                                    }
                                }
                                if(!removed)
                                {
                                    newF->addElementClause(clauseId, itReg->first);
                                    clauseId++;
                                }
                            }
                            for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                            {
                                newF->addElementClause(clauseId, (*itA)->start_->id_);
                                clauseId++;
                            }
                            originalN->addFunction(newF);


                            if(iNode->repairType > 2)
                            {
                                int nInc = nFuncInconsistWithLabel(solution, newF);
                                if(nInc > CONSISTENT)
                                {
                                    if(nInc == DOUBLE_INC)
                                    {
                                        isSol = searchNonComparableFunctions(solution, iNode, emptyList, (*itAdd), (*itRemove));
                                    }
                                    else
                                    {
                                        iNode->generalization_ = nInc == SINGLE_INC_GEN;
                                        isSol = searchComparableFunctions(solution, iNode, emptyList, (*itAdd), (*itRemove));
                                    }
                                }
                                else
                                {
                                    isSol = true;
                                    RepairSet * repairSet = new RepairSet();
                                    //remove and add edges in solution repair set
                                    for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                                    {
                                        repairSet->removeEdge((*itRem));
                                    }
                                    for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                                    {
                                        repairSet->addEdge((*itA));
                                    }
                                    repairSet->addRepairedFunction(newF);
                                    solution->addRepairSet(iNode->id_, repairSet);
                                }
                            }
                            else
                            {
                                //test only functions
                                std::vector<Function*> fCandidates;
                                fCandidates.push_back(newF);
                                int bestFunctionLevel = -1;
                                while(!fCandidates.empty())
                                {
                                    Function* candidate = fCandidates.front();
                                    fCandidates.erase (fCandidates.begin());

                                    if(bestFunctionLevel >= 0 && candidate->level_ > bestFunctionLevel)
                                    {
                                        //function is from a higher level than expected
                                        continue;
                                    }

                                    if(isFuncConsistentWithLabel(solution, candidate))
                                    {
                                        isSol = true;
                                    }


                                    if(isSol)
                                    {
                                        RepairSet * repairSet = new RepairSet();

                                        repairSet->addRepairedFunction(candidate);

                                        //remove and add edges in solution repair set
                                        for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                                        {
                                            repairSet->removeEdge((*itRem));
                                        }
                                        for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                                        {
                                            repairSet->addEdge((*itA));
                                        }

                                        solution->addRepairSet(iNode->id_, repairSet);
                                        bestFunctionLevel = candidate->level_;
                                        if(!Configuration::isActive("allOpt"))
                                        {
                                            if(Configuration::isActive("debug"))
                                                std::cout << "DEBUG: no more solutions - allOpt\n";
                                            break;;
                                        }
                                        
                                    }
                                    if(bestFunctionLevel >= 0 && !Configuration::isActive("showAllFunctions"))
                                    {
                                        if(Configuration::isActive("debug"))
                                            std::cout << "DEBUG: no more function solutions\n";
                                        break;           
                                    }

                                    if(candidate->getNumberOfRegulators() < 2)
                                    {
                                        if(Configuration::isActive("debug"))
                                            std::cout << "DEBUG: function with 1 regulator\n";
                                        //there is no possible condidates for 1 regulator function
                                        break;
                                    }
                                    //renew candidates if solution level not found yet
                                    if(bestFunctionLevel < 0 || candidate->level_ < bestFunctionLevel)
                                    {
                                        if(Configuration::isActive("debug"))
                                            std::cout << "DEBUG: updating solutions\n";
                                        std::vector<Function*> fauxCandidates = ASPHelper::getFunctionReplace(candidate, iNode->generalization_, network->input_file_network_);
                                        if(!fauxCandidates.empty())
                                            fCandidates.insert(fCandidates.end(),fauxCandidates.begin(),fauxCandidates.end());
                                    }

                                }
                            }

                            //test with edge flips
                            if(!isSol)
                                isSol = repairNodeConsistencyFlippingEdges(solution, iNode, (*itAdd), (*itRemove));


                            //add and remove edges for the original network
                            for(auto itRem = (*itRemove).begin(), endRem = (*itRemove).end(); itRem != endRem; itRem++)
                            {
                                network->addEdge((*itRem));
                            }
                            for(auto itA = (*itAdd).begin(), endA = (*itAdd).end(); itA != endA; itA++)
                            {
                                network->removeEdge((*itA));
                            }

                            //put back the original function
                            originalN->addFunction(originalF);

                            if(isSol)
                            {
                                solFound = true;
                                if(!Configuration::isActive("allOpt"))
                                {
                                    if(Configuration::isActive("debug"))
                                        std::cout << "DEBUG: no more solutions - allOpt\n";
                                    return;
                                }
                            }
                        }
                    }
                }

            }

        }

        if(solFound)
        {
            break;
        }

    }


    if(!solFound)
    {
        //TODO add or remove edges
        solution->hasImpossibility = true;
        std::cout << "WARN: Not possible to repair node " << iNode->id_ << std::endl;
    }
    return;
}

bool searchComparableFunctions(InconsistencySolution* inconsistency, InconsistentNode* iNode, std::vector<Edge*> flippedEdges, std::vector<Edge*> addedEdges, std::vector<Edge*> removedEdges)
{
    bool solFound = false;

    if(Configuration::isActive("function_ASP"))
    {

        //each function must have a list of replacement candidates and each must be tested until it works
        Function* originalF = network->getNode(iNode->id_)->getFunction();
        if(originalF == nullptr)
        {
            std::cout << "WARN: Inconsistent node " << iNode->id_ << " without regulatory function." << std::endl;
            inconsistency->hasImpossibility = true;
            return false;
        }

        //if the function only has 1 regulator then it is not possible to change the function
        //better try to flip the sign of the edge
        //check top function for the necessity of flipping an edge <- yhis only works for single profile
        
        //if(originalF->getNumberOfRegulators() < 2 || !checkPointFunction(inconsistency, originalF, iNode->generalization_))
        if(originalF->getNumberOfRegulators() < 2)
        {
            return false;
        }

        // get the possible candidates to replace the inconsistent function
        bool functionRepaired = false;
        int repairedFunctionLevel = -1;
        std::vector<Function*> tCandidates = ASPHelper::getFunctionReplace(originalF,iNode->generalization_, network->input_file_network_);
        while(!tCandidates.empty())
        {
            Function* candidate = tCandidates.front();
            tCandidates.erase (tCandidates.begin());
            
            if(functionRepaired && candidate->level_ > repairedFunctionLevel)
            {
                //function is from a higher level than expected
                continue;
            }

            if(isFuncConsistentWithLabel(inconsistency, candidate))
            {

                RepairSet * repairSet = new RepairSet();
                repairSet->addRepairedFunction(candidate);
                //add flipped edges in solution repair set
                for(auto itEdge = flippedEdges.begin(), endEdge = flippedEdges.end(); itEdge != endEdge; itEdge++)
                {
                    repairSet->addFlippedEdge((*itEdge));
                }
                //add and remove edges in solution repair set
                for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                {
                    repairSet->removeEdge((*itRem));
                }
                for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                {
                    repairSet->removeEdge((*itAdd));
                }
                inconsistency->addRepairSet(iNode->id_, repairSet);
                functionRepaired = true;
                solFound = true;
                repairedFunctionLevel = candidate->level_;
                if(!Configuration::isActive("showAllFunctions"))
                {
                    break;
                }
            }

            std::vector<Function*> tauxCandidates = ASPHelper::getFunctionReplace(candidate,iNode->generalization_, network->input_file_network_);
            if(!tauxCandidates.empty())
                tCandidates.insert(tCandidates.end(),tauxCandidates.begin(),tauxCandidates.end());
            
        }
        
    }
    else
    {
    //TODO support other solvers
    }

    return solFound;

}



bool searchNonComparableFunctions(InconsistencySolution* inconsistency, InconsistentNode* iNode, std::vector<Edge*> flippedEdges, std::vector<Edge*> addedEdges, std::vector<Edge*> removedEdges)
{
    bool solFound = false;
    std::vector<Function*> candidates;
    std::vector<Function*> consistentFunctions;

    //to find the best possible functions comparing the levels
    bool levelCompare = Configuration::isActive("compareLevelFunction");
    std::vector<Function*> bestBelow;
    std::vector<Function*> bestAbove;
    std::vector<Function*> equalLevel;


    //each function must have a list of replacement candidates and each must be tested until it works
    Function* originalF = network->getNode(iNode->id_)->getFunction();
    std::map<std::string,int> originalMap = originalF->getRegulatorsMap();
    if(originalF->getNumberOfRegulators() < 2)
    {
        //repairNodeConsistencyWithTopologyChanges(inconsistency, iNode);
        return false;
    }

    //construction of new function to start search
    // TODO consider the nearest extreme
    Function* newF = new Function(originalF->node_, 1);

    //if the function is in the lower half of the Hasse diagram,
    //start search at the most specific function and generalize
    //else start at the most generic function and specify
    bool isGeneralize = true;
    if(levelCompare)
    {
        if(Configuration::isActive("debug"))
            printf("DEBUG: Starting half determination\n");
        isGeneralize = isFunctionInBottomHalf(originalF);
        if(Configuration::isActive("debug"))
            printf("DEBUG: End half determination\n");
        if(Configuration::isActive("debug"))
            printf("Performing a search going %s\n", isGeneralize ? "up" : "down");
    }
    int cindex = 1;
    for(auto it = originalMap.begin(), end = originalMap.end(); it!= end; it++)
    {
        newF->addElementClause(cindex, it->first);
        if(!isGeneralize)
        {
            cindex++;
        }

    }
    candidates.push_back(newF);
    if(Configuration::isActive("debug"))
        printf("Finding functions for double inconsistency in %s %s (%d regulators)\n\n",originalF->printFunction().c_str(), originalF->printFunctionFullLevel().c_str(), originalF->getNumberOfRegulators());

    // get the possible candidates to replace the inconsistent function
    bool functionRepaired = false;
    int repairedFunctionLevel = -1;
    int counter=0;
    while(!candidates.empty())
    {
        counter++;
        Function* candidate = candidates.front();
        candidates.erase (candidates.begin());
        bool isConsistent = false;
        
        if(isIn(consistentFunctions, candidate))
        {
            continue;
        }

        if(isFuncConsistentWithLabel(inconsistency, candidate))
        {
            isConsistent = true;
            consistentFunctions.push_back(candidate);
            if(!functionRepaired && Configuration::isActive("debug"))
                printf("\tfound first function at level %d %s\n",candidate->level_, candidate->printFunction().c_str());
            functionRepaired = true;
            solFound = true;
            if(repairedFunctionLevel == -1)
                repairedFunctionLevel = candidate->level_;
            
            if(levelCompare)
            {
                int cmp = originalF->compareLevel(candidate);
                if(cmp == 0)
                {
                    //same level function
                    equalLevel.push_back(candidate);
                    continue;
                }
                if(isGeneralize && cmp < 0 && !equalLevel.empty())
                {
                    //if the candidate is above the original and we are going up and we found an equal level function
                    //then do nothing - do not continue explore this branch
                    continue;
                }
                if(!isGeneralize && cmp > 0 && !equalLevel.empty())
                {
                    //if the candidate is below the original and we are going down and we found an equal level function
                    //then do nothing - do not continue explore this branch
                    continue;
                }
                if(cmp > 0 && equalLevel.empty())
                {
                    //candidate below original function
                    if(bestBelow.empty())
                    {
                        bestBelow.push_back(candidate);
                    }
                    else
                    {
                        Function * representant = bestBelow.front();
                        int repCmp = representant->compareLevel(candidate);
                        if(repCmp == 0)
                        {
                            bestBelow.push_back(candidate);
                        }
                        if(repCmp < 0)
                        {
                            bestBelow.clear();
                            bestBelow.push_back(candidate);
                        }
                    }
                    if(!isGeneralize)
                    {
                        //if we are going down and found a below function, do not continue explore this branch
                        continue;
                    }
                }
                if(cmp < 0 && equalLevel.empty())
                {
                    //candidate above the original function
                    if(bestAbove.empty())
                    {
                        bestAbove.push_back(candidate);
                    }
                    else
                    {
                        Function * representant = bestAbove.front();
                        int repCmp = representant->compareLevel(candidate);
                        if(repCmp == 0)
                        {
                            bestAbove.push_back(candidate);
                        }
                        if(repCmp > 0)
                        {
                            bestAbove.clear();
                            bestAbove.push_back(candidate);
                        }
                        
                    }
                    if(isGeneralize)
                    {
                         //if we are going up and found an above function, do not continue explore this branch
                        continue;
                    }
                }
            }

        }
        //not consistent candidate
        else
        {
            if(candidate->son_consistent)
                continue;
            if(levelCompare)
            {
                if(isGeneralize && !equalLevel.empty() && candidate->compareLevel(originalF) > 0)
                {
                    continue;
                }
                if(!isGeneralize && !equalLevel.empty() && candidate->compareLevel(originalF) < 0)
                {
                    continue;
                }
                if(isGeneralize && !bestAbove.empty())
                {
                    Function* representant = bestAbove.front();
                    int repCmp = representant->compareLevel(candidate);
                    if(repCmp < 0)
                    {
                        continue;
                    }
                }
                if(!isGeneralize && !bestBelow.empty())
                {
                    Function* representant = bestBelow.front();
                    int repCmp = representant->compareLevel(candidate);
                    if(repCmp > 0)
                    {
                        continue;
                    }
                }
            }
        }
        
        std::vector<Function*> tauxCandidates = ASPHelper::getFunctionReplace(candidate,isGeneralize, network->input_file_network_);
        for(auto it = tauxCandidates.begin(), end = tauxCandidates.end(); it!=end; it++)
        {
            (*it)->son_consistent = isConsistent;
            if(!isIn(candidates, (*it)))
                candidates.push_back((*it));
        }
        
    }
    if(Configuration::isActive("debug"))
    {
        if(functionRepaired)
        {
            if(levelCompare)
            {
                printf("\nPrinting consistent functions found using level comparison\n");
                if(!equalLevel.empty())
                {
                    printf("Looked at %d functions. Found %d consistent. To return %d functions of same level\n\n", counter, (int)consistentFunctions.size(), (int)equalLevel.size());
                    for(auto it = equalLevel.begin(), end = equalLevel.end(); it != end; it++)
                    {
                        printf("\t %s %s (distance from bottom: %d)\n", (*it)->printFunction().c_str(), (*it)->printFunctionFullLevel().c_str(), (*it)->level_);
                    }
                }
                else
                {
                    printf("Looked at %d functions. Found %d consistent. To return %d functions\n\n", counter, (int)consistentFunctions.size(), (int)bestBelow.size()+(int)bestAbove.size());
                    for(auto it = bestBelow.begin(), end = bestBelow.end(); it != end; it++)
                    {
                        printf("\t %s %s (distance from bottom: %d)\n", (*it)->printFunction().c_str(), (*it)->printFunctionFullLevel().c_str(), (*it)->level_);
                    }
                    for(auto it = bestAbove.begin(), end = bestAbove.end(); it != end; it++)
                    {
                        printf("\t %s %s (distance from bottom: %d)\n", (*it)->printFunction().c_str(), (*it)->printFunctionFullLevel().c_str(), (*it)->level_);
                    }
                }
                
            }
            else
            {
                printf("\nPrinting consistent functions found\n");
                printf("Looked at %d functions. Found %d functions\n\n", counter, (int)consistentFunctions.size());
                //for(auto it = consistentFunctions.begin(), end = consistentFunctions.end(); it != end; it++)
                //{
                //    printf("\t %s %s (distance from bottom: %d)\n", (*it)->printFunction().c_str(), (*it)->printFunctionFullLevel().c_str(), (*it)->level_);
                //}
            }
            
        }
        else
        {
            printf("no consistent functions found - %d\n", counter);
        }
    }

    //add repair sets to the solution
    if(solFound)
    {
        if(levelCompare)
        {
            if(!equalLevel.empty())
            {
                for(auto it = equalLevel.begin(), end = equalLevel.end(); it != end; it++)
                {
                    RepairSet * repairSet = new RepairSet();
                    repairSet->addRepairedFunction((*it));

                    //add flipped edges in solution repair set
                    for(auto itEdge = flippedEdges.begin(), endEdge = flippedEdges.end(); itEdge != endEdge; itEdge++)
                    {
                        repairSet->addFlippedEdge((*itEdge));
                    }
                    //add and remove edges in solution repair set
                    for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                    {
                        repairSet->removeEdge((*itRem));
                    }
                    for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                    {
                        repairSet->removeEdge((*itAdd));
                    }
                    inconsistency->addRepairSet(iNode->id_, repairSet);
                }
            }
            else
            {
                for(auto it = bestBelow.begin(), end = bestBelow.end(); it != end; it++)
                {
                    RepairSet * repairSet = new RepairSet();
                    repairSet->addRepairedFunction((*it));

                    //add flipped edges in solution repair set
                    for(auto itEdge = flippedEdges.begin(), endEdge = flippedEdges.end(); itEdge != endEdge; itEdge++)
                    {
                        repairSet->addFlippedEdge((*itEdge));
                    }
                    //add and remove edges in solution repair set
                    for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                    {
                        repairSet->removeEdge((*itRem));
                    }
                    for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                    {
                        repairSet->removeEdge((*itAdd));
                    }
                    inconsistency->addRepairSet(iNode->id_, repairSet);
                }
                for(auto it = bestAbove.begin(), end = bestAbove.end(); it != end; it++)
                {
                    RepairSet * repairSet = new RepairSet();
                    repairSet->addRepairedFunction((*it));

                    //add flipped edges in solution repair set
                    for(auto itEdge = flippedEdges.begin(), endEdge = flippedEdges.end(); itEdge != endEdge; itEdge++)
                    {
                        repairSet->addFlippedEdge((*itEdge));
                    }
                    //add and remove edges in solution repair set
                    for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                    {
                        repairSet->removeEdge((*itRem));
                    }
                    for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                    {
                        repairSet->removeEdge((*itAdd));
                    }
                    inconsistency->addRepairSet(iNode->id_, repairSet);
                }
            }
        }
        else
        {
            for(auto it = consistentFunctions.begin(), end = consistentFunctions.end(); it != end; it++)
            {
                RepairSet * repairSet = new RepairSet();
                repairSet->addRepairedFunction((*it));

                //add flipped edges in solution repair set
                for(auto itEdge = flippedEdges.begin(), endEdge = flippedEdges.end(); itEdge != endEdge; itEdge++)
                {
                    repairSet->addFlippedEdge((*itEdge));
                }
                //add and remove edges in solution repair set
                for(auto itRem = removedEdges.begin(), endRem = removedEdges.end(); itRem != endRem; itRem++)
                {
                    repairSet->removeEdge((*itRem));
                }
                for(auto itAdd = addedEdges.begin(), endAdd = addedEdges.end(); itAdd != endAdd; itAdd++)
                {
                    repairSet->removeEdge((*itAdd));
                }
                inconsistency->addRepairSet(iNode->id_, repairSet);
            }
        }

    }
    return solFound;

}

bool isIn(std::vector<Function*> list, Function* item)
{
    for(auto it = list.begin(), end = list.end(); it!= end; it++)
    {
        Function* aux = (*it);
        if(item->isEqual(aux))
            return true;
    }
    return false;
}


void printAllFunctions(int dimension)
{
 
    std::vector<Function*> candidates;
    std::vector<Function*> computedFunctions;

    //construction of new function to start search
    Function* newF = new Function("t", 1);
    for(int i = 1; i<= dimension; i++)
    {
        newF->addElementClause(1, std::to_string(i));
    }
    candidates.push_back(newF);

    // get the possible candidates to replace the inconsistent function

    int counter=0;
    while(!candidates.empty())
    {
        counter++;
        Function* candidate = candidates.front();
        candidates.erase (candidates.begin());

        if(isIn(computedFunctions, candidate))
        {
            continue;
        }
        computedFunctions.push_back(candidate);
  
        std::vector<Function*> tauxCandidates = ASPHelper::getFunctionReplace(candidate,true, network->input_file_network_);
        for(auto it = tauxCandidates.begin(), end = tauxCandidates.end(); it!=end; it++)
        {
            if(!isIn(candidates, (*it)))
                candidates.push_back((*it));
        }
        
    }

    std::sort(computedFunctions.begin(), computedFunctions.end(), myFunctionCompare);

    printf("\nPrinting functions with %d arguments\n", dimension);
    for(auto it = computedFunctions.begin(), end = computedFunctions.end(); it != end; it++)
    {
        printf("\t %s %s\n", (*it)->printFunction().c_str(), (*it)->printFunctionFullLevel().c_str());
    }

    printf("\nLooked at %d functions and computed %d functions\n", counter, (int)computedFunctions.size());
    

    return;

}

bool myFunctionCompare(Function * f1, Function * f2)
{
    if(f1->compareLevel(f2) < 0)
        return true;
    return false;
}

bool isFunctionInBottomHalf(Function *f)
{
    if(Configuration::isActive("exactMiddleFunctionDetermination"))
    {
        if(Configuration::isActive("debug"))
            printf("DEBUG: Half determination by state\n");
        return isFunctionInBottomHalfByState(f);
    }
    int n = f->getNumberOfRegulators();
    int n2 = n/2;
    std::vector<int> midLevel;
    for(int i = 0; i < n; i++)
    {
        midLevel.push_back(n2);
    }
    return f->compareLevel(midLevel) < 0;

}

int nFuncInconsistWithLabel(InconsistencySolution* labeling, Function* f)
{
    int result = CONSISTENT;
    //verify for each profile
    for(auto it = labeling->vlabel_.begin(), end = labeling->vlabel_.end(); it != end; it++)
    {
        int ret = nFuncInconsistWithLabel(labeling, f, it->first);
        if(result == CONSISTENT)
        {
            result = ret;
        }
        else
        {
            if(ret != result)
            {
                result = DOUBLE_INC;
                break;
            }
        }
    }
    return result;
}

int nFuncInconsistWithLabel(InconsistencySolution* labeling, Function* f, std::string profile)
{
    for(int i = 1; i <= f->nClauses_; i++)
    {
        bool isClauseSatisfiable = true;
        std::vector<std::string> clause = f->clauses_[i];
        for(auto it = clause.begin(), end = clause.end(); it!=end; it++)
        {
            Edge* e = network->getEdge((*it), f->node_);
            if(e != nullptr)
            {
                //positive interaction
                if(e->getSign() > 0)
                {
                    if(labeling->vlabel_[profile][(*it)] == 0)
                    {
                        isClauseSatisfiable = false;
                        break;
                    }
                }
                //negative interaction
                else
                {
                    if(labeling->vlabel_[profile][(*it)] > 0)
                    {
                        isClauseSatisfiable = false;
                        break;
                    }
                }
            }
            else{
                std::cout << "WARN: Missing edge from " << (*it) << " to " << f->node_ << std::endl;
                return false;
            }
        }
        if(isClauseSatisfiable)
        {
            if(labeling->vlabel_[profile][f->node_] == 1)
            {
                return CONSISTENT;
            }
            else
            {
                return SINGLE_INC_PART;
            }
        }

    }
    if(labeling->vlabel_[profile][f->node_] == 0)
    {
        return CONSISTENT;
    }
    return SINGLE_INC_GEN;
}

//TODO put this in the function object as an object method
bool isFunctionInBottomHalfByState(Function *f)
{
    std::map<std::string,int> regMap = f->getRegulatorsMap();
    int regulators = f->getNumberOfRegulators();
    int entries = (int) pow(2, regulators);
    int nOne = 0;
    int nZero = 0;

    for(int entry = 0; entry < entries; entry++)
    {
        std::bitset<16> bits (entry);
        std::map<std::string,int> input;
        int bitIndex = 0;
        for(auto it = regMap.begin(), end = regMap.end(); it!=end; it++)
        {
            input.insert(std::pair<std::string, int>(it->first, bits.test(bitIndex) ? 1 : 0));
            bitIndex++;
        }
        if(getFunctionValue(f, input))
        {
            nOne++;
            if(nOne > entries / 2)
                break;
        }
        else
        {
            nZero++;
            if(nZero > entries / 2)
                break;
        }

    }
    if(nZero > entries / 2)
    {
        return true;
    }
    return false;

}

bool getFunctionValue(Function * f, std::map<std::string,int> input)
{
    for(int i = 1; i <= f->nClauses_; i++)
    {
        bool isClauseSatisfiable = true;
        std::vector<std::string> clause = f->clauses_[i];
        for(auto it = clause.begin(), end = clause.end(); it!=end; it++)
        {
            Edge* e = network->getEdge((*it), f->node_);
            if(e != nullptr)
            {
                //positive interaction
                if(e->getSign() > 0)
                {
                    if(input[(*it)] == 0)
                    {
                        isClauseSatisfiable = false;
                        break;
                    }
                }
                //negative interaction
                else
                {
                    if(input[(*it)] > 0)
                    {
                        isClauseSatisfiable = false;
                        break;
                    }
                }
            }
            else{
                std::cout << "WARN: Missing edge from " << (*it) << " to " << f->node_ << std::endl;
                return false;
            }
        }
        if(isClauseSatisfiable)
            return true;

    }
    return false;
}
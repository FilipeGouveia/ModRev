## Corrupted Input Network for Model Revision Procedure

Examples of corrupted models are provided for five well known biological networks:
* boolean_cell_cycle - the core network controlling the mammalian cell cycle by Fauré et al. (2006)
* fissionYeastDavidich2008 - the cell-cycle regulatory network of fission yeast by Davidich and Bornholdt (2008)
* SP_1cell - the segment polarity network which plays a role in the fly embryo segmentation by Sánchez et al. (2002)
* TCRsig40 - the T-Cell Receptor signaling network by Klamt et al. (2006)
* thNetworkGarg2007 - the regulatory network controlling T-helper cell differentiation by Mendoza and xenarios (2006)


Each instance is composed of three files:
* A log file (.log) with the changes made to the original model
* A model file (net.lp) with only the model, without experimental observations.
* A model with stable state observations file (net-att.lp).

# Model Revision of Boolean Regulatory Networks in Stable State

Model revision tool to repair inconsistent logical models under stable state.

## Getting Started

These instructions will let you compile and use our tool for tests purposes.

### Configuration

This tool is only available for macOS or Linux.
This tool relies on [clingo](https://sourceforge.net/projects/potassco/files/clingo/) 4.5.4 to determine inconsistencies and determine function candidates.
Please do
```
cd ModelRevisionCpp
make config
```
This will copy the correspondent clingo to the *ASP/bin* folder.
If you want to use your own clingo, feel free to add a line in *ModelRevisionCpp/config.txt*. For example, add the following line:
```
ASP_solver=~/my/own/directory/clingo
```

### Compiling

Make sure you are in the *ModelRevisionCpp* folder.
```
cd ModelRevisionCpp
```
To compile do:
```
make
```

## Usage

### Model Revision Tool

To use the model revision tool, make sure you are in the *ModelRevisionCpp* folder.
```
cd ModelRevisionCpp
```

Examples of inconsistent networks are provided in *inputNetworks* folder.

To use this tool, do:

```
./modrev <input network>
```

Example:
```
./modrev ../inputNetworks/boolean_cell_cycle/01/boolean_cell_cycle-50-0-0-0-net-att.lp
```

The format of the input file is described in more detail in *ASP/README.md*.

## Tests

### Examples provided

Examples of models are provided in the *inputNetworks* folder.
Each instance is composed of three files:
* A log file (.log) with the changes made to the original model
* A model file (net.lp) with only the model, without experimental observations.
* A model with observations file (net-att.lp).

In order to correctly test the model revision tool, please use the model with observations file (net-att.lp).

### Changing Model Tool

We also provide the tool used to change a model probabilistically.

To configure and compile do:
```
cd RandomNetworkmess
make config
make
```

To use, make sure you are in the *RandomNetworkMess* folder:
```
./modmess <original model> <f> <e> <r> <a> <output model> <output log>
```
where:
* *f* [0;100] is an integer probability of changing a regulatory function
* *e* [0;100] is an integer probability of flipping the sign of an edge
* *r* [0;100] is an integer probability of removing an existing edge
* *a* [0;100] is an integer probability of adding a missing edge


For example:
```
./modmess ../originalNetworks/boolean_cell_cycle/original/boolean_cell_cycle.lp 50 0 0 0 output_model.lp output_log.txt
```

Please make sure to add the stable states observations to a changed model. For example:
```
cat output_model.lp ../originalNetworks/boolean_cell_cycle/original/attractors.lp > output_model_att.lp
```

## Authors
* Filipe gouveia
* Inês lynce
* pedro Monteiro